/*Name:D.vijay rohit(25040B_019)
Date:15-03-26
Description:
This project implements a C program to read and edit ID3v2.3 tags in MP3 files.
It allows viewing and updating Title, Artist, Album, Year, Genre, and Track Number.
The program validates MP3 files, ensuring correct ID3 identifier and version.
It uses syncsafe-to-integer conversion to accurately calculate tag sizes.
Frame data is handled safely with dynamic memory allocation and temporary file editing.
User-friendly options (-t, -a, -A, -y, -m, -c) enable quick metadata updates.
The program ensures robustness by handling invalid files and errors gracefully.*/
#include <stdio.h>
#include <string.h>
#include "mp3.h"
int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        printf("Usage:\n");
        printf("Read  : %s -r file.mp3\n", argv[0]);
        printf("Edit  : %s file.mp3 -t \"value\"\n", argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "-r") == 0)
    {
        FILE *fp = fopen(argv[2], "rb");
        if (!fp)
        {
            printf("Cannot open file\n");
            return 1;
        }

        read_id3v23(fp);
        fclose(fp);
        return 0;
    }

    if (argc == 4)
    {
        if (!edit_id3v23(argv[1], argv[2], argv[3]))
            return 1;
        return 0;
    }

    printf("Invalid command\n");
    return 1;
}