#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mp3.h"

//Convert syncsafe to normal int
int syncsafe_to_int(unsigned char size[4])
{
    return (size[0] << 21) |(size[1] << 14) |(size[2] << 7)  |(size[3]);//Converts 4-byte ID3v2.3 tag size to integer (syncsafe_to_int()).
}

//Validate MP3 ID3v2.3
int validate_mp3(FILE *fp)
{
    ID3V2Header header;

    rewind(fp);

    if (fread(&header, 1, 10, fp) != 10)
        return 0;

    if (strncmp(header.id, "ID3", 3) != 0)//Checks "ID3" identifier and ensures version 2.3 (validate_mp3()).
        return 0;

    if (header.ver_major != 3)
        return 0;

    return 1;
}

//READ MODE 

void read_id3v23(FILE *fp)
{
    if (!validate_mp3(fp))
    {
        printf("Invalid ID3v2.3 file\n");
        return;
    }

    ID3V2Header header;

    rewind(fp);
    fread(&header, 1, 10, fp);

    int tag_size = syncsafe_to_int(header.size);

    printf("ID3v2.%d.%d detected\n",
           header.ver_major,
           header.ver_minor);

    int bytes_read = 0;

    while (bytes_read < tag_size)//read_id3v23() reads each frame (ID, size, flags, data) and Prints text frames skipping the encoding byte.
    {
        char frame_id[5] = {0};
        unsigned char size_bytes[4];
        unsigned char flags[2];

        //Read frame header
        if (fread(frame_id, 1, 4, fp) != 4)
            break;

        //STOP if padding or invalid frame
        if (!(frame_id[0] >= 'A' && frame_id[0] <= 'Z'))
            break;

        if (fread(size_bytes, 1, 4, fp) != 4)
            break;

        if (fread(flags, 1, 2, fp) != 2)
            break;

        //Each frame: 4-byte ID + 4-byte size + 2-byte flags + frame content.
        int frame_size =(size_bytes[0] << 24)|(size_bytes[1] << 16)|(size_bytes[2] << 8)|(size_bytes[3]);

        if (frame_size <= 0)
            break;

        char *data = malloc(frame_size);//Allocates memory for frame content and frees it after use to avoid leaks.
        if (!data)
            break;

        fread(data, 1, frame_size, fp);

        //text frames have first byte encoding
        if (frame_size > 1)
        {
            printf("%s: %.*s\n",
                   frame_id,
                   frame_size - 1,
                   data + 1);
        }

        free(data);

        bytes_read += 10 + frame_size;
    }
}

//EDIT MODE

int edit_id3v23(const char *filename,const char *option,const char *value)//edit_id3v23() modifies title, artist, album, year, genre, or track and uses a temporary file to safely update frames without losing audio data.
{
    FILE *src = fopen(filename, "rb");
    if (!src)
    {
        printf("Cannot open source file\n");
        return 0;
    }

    if (!validate_mp3(src))
    {
        printf("Invalid ID3v2.3 file\n");
        fclose(src);
        return 0;
    }

    FILE *dest = fopen("temp.mp3", "wb");
    if (!dest)
    {
        printf("Cannot create temp file\n");
        fclose(src);
        return 0;
    }

    //Copy header unchanged
    ID3V2Header header;
    rewind(src);
    fread(&header, 1, 10, src);
    fwrite(&header, 1, 10, dest);

    int tag_size = syncsafe_to_int(header.size);

    char target[5] = "";

    if (strcmp(option, "-t") == 0) strcpy(target, "TIT2");
    else if (strcmp(option, "-a") == 0) strcpy(target, "TPE1");
    else if (strcmp(option, "-A") == 0) strcpy(target, "TALB");
    else if (strcmp(option, "-y") == 0) strcpy(target, "TYER");
    else if (strcmp(option, "-m") == 0) strcpy(target, "TCON");
    else if (strcmp(option, "-c") == 0) strcpy(target, "TRCK");
    else
    {
        printf("Invalid option\n");
        fclose(src);
        fclose(dest);
        return 0;
    }

    int bytes_read = 0;

    while (bytes_read < tag_size)
    {
        char frame_id[5] = {0};
        unsigned char size_bytes[4];
        unsigned char flags[2];

        if (fread(frame_id, 1, 4, src) != 4)
            break;

        if (!(frame_id[0] >= 'A' && frame_id[0] <= 'Z'))
            break;

        fread(size_bytes, 1, 4, src);
        fread(flags, 1, 2, src);

        int old_size =(size_bytes[0] << 24) |(size_bytes[1] << 16) |(size_bytes[2] << 8) |(size_bytes[3]);

        if (strncmp(frame_id, target, 4) == 0)
        {
            //Write new frame
            int new_size = strlen(value) + 1;

            fwrite(frame_id, 1, 4, dest);

            unsigned char new_size_bytes[4];
            new_size_bytes[0] = (new_size >> 24) & 0xFF;
            new_size_bytes[1] = (new_size >> 16) & 0xFF;
            new_size_bytes[2] = (new_size >> 8) & 0xFF;
            new_size_bytes[3] = new_size & 0xFF;

            fwrite(new_size_bytes, 1, 4, dest);
            fwrite(flags, 1, 2, dest);

            //encoding byte
            fputc(0, dest);
            fwrite(value, 1, strlen(value), dest);

            //skip old data
            fseek(src, old_size, SEEK_CUR);
        }
        else
        {
            //Copy frame unchanged
            fwrite(frame_id, 1, 4, dest);
            fwrite(size_bytes, 1, 4, dest);
            fwrite(flags, 1, 2, dest);

            char *buffer = malloc(old_size);
            fread(buffer, 1, old_size, src);
            fwrite(buffer, 1, old_size, dest);
            free(buffer);
        }

        bytes_read += 10 + old_size;
    }

    //Copy remaining audio data
    fseek(src, 10 + tag_size, SEEK_SET);

    int ch;
    while ((ch = fgetc(src)) != EOF)
        fputc(ch, dest);

    fclose(src);
    fclose(dest);

    //Validate temp file
    FILE *check = fopen("temp.mp3", "rb");
    if (!check || !validate_mp3(check))
    {
        printf("Temp file validation failed\n");
        if (check) fclose(check);
        return 0;
    }
    fclose(check);

    remove(filename);//here deleting orignal file and replacing with new version of the file
    rename("temp.mp3", filename);

    printf("Frame updated successfully\n");

    return 1;
}