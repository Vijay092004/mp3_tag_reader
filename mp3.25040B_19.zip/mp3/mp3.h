#ifndef MP3_H
#define MP3_H

#include <stdio.h>

#pragma pack(1)
typedef struct
{
    char id[3];
    unsigned char ver_major;
    unsigned char ver_minor;
    unsigned char flags;
    unsigned char size[4];
} ID3V2Header;
#pragma pack()

int validate_mp3(FILE *fp);
void read_id3v23(FILE *fp);
int edit_id3v23(const char *filename,const char *option, const char *value);

#endif 